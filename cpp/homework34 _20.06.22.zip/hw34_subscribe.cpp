#include "hw34_subscribe.h"
#include <iostream>



void hw34_subscribe::printSubs() {
	std::cout << nameS.surname << " " << nameS.name << " " << nameS.patronymic << " " << phoneS << " " << addInfoS;
}