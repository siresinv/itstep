// STEP _CPP _classwork7 _09.02.22 _task6


#include <iostream>

/*
��� �������
*/

int main()
{
	setlocale(0, "");
	
	for (int i = 0; i < 7; i++)
	{

		for (int j = 0; j < 9; j++)
		{
			std::cout << "[___]";
		}

		std::cout << std::endl;
	}

	
	
	return 0;

}