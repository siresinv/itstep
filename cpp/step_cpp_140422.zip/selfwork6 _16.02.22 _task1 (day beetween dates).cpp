﻿// STEP _CPP _selfwork6 _16.02.22 _task1 (days beetween dates)
// days beetween dates

#include <iostream>



int main()
{


	return 0;


}
