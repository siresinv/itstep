﻿// STEP _CPP _classwork14 _23.03.22 _task2
/*
	ПАРАМЕТРЫ ПО-УМОЛЧАНИЮ ВСЕГДА ИДУТ В КОНЦЕ
*/



void foot(int i, int j = 7);
void foot(int i, int j = 2, int k);
void foot(int i, int j = 3, int k = 7);
void foot(int i = 1, int j = 2, int k = 3);
void foot(int i = -3, int j);




