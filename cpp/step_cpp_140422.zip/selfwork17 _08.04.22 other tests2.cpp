﻿// STEP _CPP _selfwork17 _08.04.22 other tests2

#include <iostream>




int main() {

	int intA = 777;
	char chB = 20;

	int x = intA + chB;

	
	std::cout << int(chB) << " ";
	chB = int(2000);
	x = intA + chB;
	std::cout << x;




}


