﻿// STEP C++ Practic.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
using namespace std;



//CW 190122
//||


int main()
{
    setlocale(0, "");


    ////cout << ++a + ++a + ++a + ++a;
    ////cout << endl;
    ////cout << a;



    //int a = 5;
    //int b = 3;
    //float c = float(a) / b;
    //cout << c;



    ////pirates = pirates - mir + 1;
    //++pirates -= mir; //!!!



    //cout << ((5 > 3) || (3 > 4) && (7 > 8));



    /*int age1;
    cin >> age1;
    int age2;
    cin >> age2;
    int max = (age1 > age2) ? age1 : age2;
    cout << max;
   */
    


}



//||
//CW 190122




